# Declaring the variables
# Entering the number of elements
print("Enter the number of array")
number = int(input())
a = [0] * (number)

print("Enter the integer")
for index in range(0, number - 1 + 1, 1):
    a[index] = int(input())
maximum = a[0]
for index in range(1, number - 1 + 1, 1):
    if maximum < a[index]:
        maximum = a[index]

# Displaying the largest element
print("The greatest element is" + str(maximum))
