print("WELCOME")
print("enter number of users")
n = int(input())
balance = [0] * (n)
newbalance = [0] * (n)

for i in range(0, n - 1 + 1, 1):
    print("enter balance of user" + "-" + "i")
    balance[i] = int(input())
    print("enter the option you want to perform")
    print("1 withdrawal")
    print("2 deposit")
    print("3 referring to friend")
    option = int(input())
    if option == 1:
        if balance[i] >= 500:
            print("enter the amount to be withdraw")
            amount = int(input())
            print("collect the cash")
            newbalance[i] = balance[i] - amount
            print("newbalance[i] is" + str(newbalance[i]))
            print("Thank you")
        else:
            print("withdraw not possible due to insuffient balance")
    else:
        if option == 2:
            print("enter the amount you want to deposit")
            depositamount = int(input())
            print("the amount has been succesfully added")
            newbalance[i] = balance[i] + depositamount
            print("newbalance[i] is" + str(newbalance[i]))
        else:
            if option == 3:
                print("you got a bonus amount of 50 rupees")
                print("amount is successfully added to account")
                bonusamount = 50
                newbalance[i] = balance[i] + bonusamount
                print("newbalance[i] is" + str(newbalance[i]))
            else:
                print("invalid option")
