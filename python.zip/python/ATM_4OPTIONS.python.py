print("WELCOME TO ATM")
print("enter the account number")
accountnumber = int(input())
print("enter the pin")
pin = int(input())
if pin == 3159:
    print("balance")
    balance = int(input())
    print("please choose the operation you want to perform")
    print("1.withdraw")
    print("2.deposit")
    print("3.check balance")
    print("4.pin change")
    print("enter X")
    x = int(input())
    if x == 1:
        if balance > 500:
            print("enter the amount to be withdraw")
            amounttobewithdraw = int(input())
            print("collect the cash")
            print("thank you")
        else:
            print("withdraw not possible due to insufficient balance")
            print("collect your card")
            print("thank you for banking with us")
    else:
        if x == 2:
            print("enter the amount you want to deposit")
            amountyouwanttodeposit = int(input())
            print("the amount has succesfully been added to your account")
            print("thank you")
        else:
            if x == 3:
                print("the balance in your account is " + str(balance))
                print("thank you")
            else:
                if x == 4:
                    print("please reenter your pin")
                    pin = int(input())
                    if pin == 3159:
                        print("enter your new pin")
                        newpin = int(input())
                        print("the pin has succesfully been changed")
                        print("thank you for banking with us")
                    else:
                        print("incorrect pin is entered reenter the pin and try again")
else:
    print("pn is incorrect")
    print("remove your card")
