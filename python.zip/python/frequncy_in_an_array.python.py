# Declaring the variables
numbers = [0] * (10)

for index in range(0, 9 + 1, 1):
    
    # Giving the input for array numbers
    print("Enter " + str(index + 1) + " value")
    input = int(input())
    numbers[index] = input
print("Enter the value for which the frequency should be found")
value = int(input())
frequency = 0
for index in range(0, 9 + 1, 1):
    if numbers[index] == value:
        frequency = frequency + 1

# Displaying output
print("The frequency of the given value in array is " + str(frequency))
