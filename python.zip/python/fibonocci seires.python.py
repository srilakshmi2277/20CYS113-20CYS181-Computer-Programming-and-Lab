def fibo(n):
    a = 0
    b = 1
    print(a)
    print(b)
    for i in range(1, n - 2 + 1, 1):
        c = a + b
        a = b
        b = c
        print(c)
    print("lastvalue" + "=" + str(c))
    
    return c

# Main
print("enter the number of fibonacci series u want to be printed")
n = int(input())
fib = fibo(n)
